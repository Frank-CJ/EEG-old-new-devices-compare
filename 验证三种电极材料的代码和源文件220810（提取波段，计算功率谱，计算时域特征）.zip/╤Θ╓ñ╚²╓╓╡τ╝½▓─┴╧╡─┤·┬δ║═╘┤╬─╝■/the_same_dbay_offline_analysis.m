%% ����dbay�㷨������������
% �������յĴ��룬ͬ���˵�ǰ�㷨���޸ģ�����У�
% 	a. ȥ���˷��������źŵĲ�ֵ����������Ϊ���������źŵ���������;�����������ƽ����
% 	b. ͬ����beta��high beta��gamma��Ƶ�ʷ�Χ
% 	c. �޸��������ļ��㷽��
% 	d. ͬ��������Ԥ��������
%     �������������ݳ��ȵ�Ϊ�޸ģ���������Щ���죬����������һ����

%% clc;clear all;close all

%% pick the input will be analyzed
[filename, path] = uigetfile('.csv');
cd(path);
T = readtable(filename,'HeaderLines',4); % for non_numeric array
eeg1 = T{:,2};
eeg2 = T{:,3};
% delete Nan values if any
eeg1(isnan(eeg1)) = [];
eeg2(isnan(eeg2)) = [];
% two channels dimension equivalence check
if ~isequal(length(eeg1),length(eeg2))
    eeg1 = eeg1(1:min(length(eeg1),length(eeg2)));
    eeg2 = eeg2(1:min(length(eeg1),length(eeg2)));
end
%% filtering the raw data for further process
fs = 250; % sampling frequency
T = 1/fs;  
data_len = length(eeg1); % length of selected signal
time_vector = (0:data_len-1)/fs; % time vector
data_dur = data_len/fs; % recording duration, in seconds

%% preprocess
% stop
[b,a] = butter(5,[49 51]/(fs/2),'stop'); 
eeg1_notch = filter(b,a,eeg1);
eeg2_notch = filter(b,a,eeg2);
% low pass
[b,a] = butter(2,65/(fs/2),'low'); 
eeg1_filtered = filter(b,a,eeg1_notch);
eeg2_filtered = filter(b,a,eeg2_notch);
% high pass
[b,a] = butter(4,2/(fs/2),'high'); 
eeg1_filtered = filter(b,a,eeg1_filtered);
eeg2_filtered = filter(b,a,eeg2_filtered);

% %% �˲�ǰ�������
% figure;ax(1)=subplot(211);plot(time_vector,eeg1);
% ax(2)=subplot(212);plot(time_vector,eeg2);
% linkaxes(ax,'x');
% figure;ax(1)=subplot(211);plot(time_vector,eeg1_filtered);
% ax(2)=subplot(212);plot(time_vector,eeg2_filtered);
% linkaxes(ax,'xy');

figure;
subplot(2,1,1);pspectrum(eeg1_filtered,fs,'spectrogram','FrequencyLimits',[-1 66],'TimeResolution',2);
colormap('jet'); colorbar;caxis manual; caxis([-100 50]);title('Left channel');
subplot(2,1,2);
pspectrum(eeg2_filtered,fs,'spectrogram','FrequencyLimits',[-1 66],'TimeResolution',2);
colormap('jet'); colorbar;caxis manual; caxis([-100 50]);title('Right channel');

%% calculate the absolute power of AF7
sig = eeg1_filtered; % signal to be analysed
nfft = fs*5; % calculate the power every 5 second
hop = fs; % sliding window of 1 second with previous segment
%          delta,theta,alpha,low_beta,beta, high beta,gamma 
freq_band = [1 4; 4 8; 8 13;  13 22;  13 37; 20 37;   37 45];
f = fs * ((0:nfft/2))/nfft; %frequency resolution, depending on nfft
relative_index = freq_band*nfft/fs+1;%index of each frequency bin
freq_res = fs/nfft ;            % Ƶ�ʷֱ��� frequency resolution
%allocate space saving all the outputs
temp = []; % current segment, from i*hop to i*hop+nfft
temp_power = [];% absolute power of all frequency
delta_power_seq_eeg1 = [];theta_power_seq_eeg1 = [];
alpha_power_seq_eeg1 = [];lowB_power_seq_eeg1 = [];beta_power_seq_eeg1 = [];
highB_power_seq_eeg1 = [];gamma_power_seq_eeg1 = [];

delta_power = [];theta_power = []; alpha_power = [];
lowB_power = [];beta_power = [];highB_power = [];gamma_power = [];

num_seg = floor((data_len-nfft)/hop) - 1; % how many times you will calculate the fft
for i = 1:num_seg
    temp = sig(i*hop+1:i*hop+nfft);
%     temp_power = 2 * abs(fft(temp))/nfft;% calcuate ampltiude distribution of raw data 
    mag = abs(fft(temp,nfft));
    temp_power= 2 * mag.^2/(nfft*fs); %calculate psd of real time signal
    P1 = temp_power(1:nfft/2 + 1);
    delta_power = sum(P1(relative_index(1,1):relative_index(1,2)))*freq_res; 
    theta_power = sum(P1(relative_index(2,1):relative_index(2,2)))*freq_res;
    alpha_power = sum(P1(relative_index(3,1):relative_index(3,2)))*freq_res;
    lowB_power = sum(P1(relative_index(4,1):relative_index(4,2)))*freq_res;
    beta_power = sum(P1(relative_index(5,1):relative_index(5,2)))*freq_res;
    highB_power = sum(P1(relative_index(6,1):relative_index(6,2)))*freq_res;
    gamma_power = sum(P1(relative_index(7,1):relative_index(7,2)))*freq_res;
    delta_power_seq_eeg1 = [delta_power_seq_eeg1,delta_power];
    theta_power_seq_eeg1 = [theta_power_seq_eeg1,theta_power];
    alpha_power_seq_eeg1 = [alpha_power_seq_eeg1,alpha_power];
    lowB_power_seq_eeg1 = [lowB_power_seq_eeg1,lowB_power];
    beta_power_seq_eeg1 = [beta_power_seq_eeg1,beta_power];
    highB_power_seq_eeg1 = [highB_power_seq_eeg1,highB_power];
    gamma_power_seq_eeg1 = [gamma_power_seq_eeg1,gamma_power];
end

%calculate ralative power of each band
relative_delta_eeg1 = delta_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
relative_theta_eeg1 = theta_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
relative_alpha_eeg1 = alpha_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
relative_beta_eeg1 = beta_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
relative_gamma_eeg1 = gamma_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
%remember to clear all the allocation for temporary resources
clear temp;clear temp_power;
clear delta_power;clear theta_power;clear alpha_power;
clear lowB_power;clear beta_power;clear highB_power;clear gamma_power

%% calculate the absolute power of AF8
sig = eeg2_filtered; % signal to be analysed
%allocate space saving all the outputs
temp = []; % current segment, from i*hop to i*hop+nfft
temp_power = [];% absolute power of all frequency
delta_power_seq_eeg2 = [];theta_power_seq_eeg2 = [];
alpha_power_seq_eeg2 = [];lowB_power_seq_eeg2 = [];beta_power_seq_eeg2 = [];
highB_power_seq_eeg2 = [];gamma_power_seq_eeg2= [];
delta_power = [];theta_power = []; alpha_power = [];
lowB_power = [];beta_power = [];highB_power = [];gamma_power = [];

num_seg = floor((data_len-nfft)/hop) - 1; % how many times you will calculate the fft
for i = 1:num_seg
    temp = sig(i*hop+1:i*hop+nfft);
%     temp_power = 2 * abs(fft(temp))/nfft;% calcuate ampltiude distribution of raw data 
    mag = abs(fft(temp,nfft));
    temp_power= 2 * mag.^2/(nfft*fs); %calculate psd of real time signal
    P1 = temp_power(1:nfft/2 + 1);
    delta_power = sum(P1(relative_index(1,1):relative_index(1,2)))*freq_res; 
    theta_power = sum(P1(relative_index(2,1):relative_index(2,2)))*freq_res;
    alpha_power = sum(P1(relative_index(3,1):relative_index(3,2)))*freq_res;
    lowB_power = sum(P1(relative_index(4,1):relative_index(4,2)))*freq_res;
    beta_power = sum(P1(relative_index(5,1):relative_index(5,2)))*freq_res;
    highB_power = sum(P1(relative_index(6,1):relative_index(6,2)))*freq_res;
    gamma_power = sum(P1(relative_index(7,1):relative_index(7,2)))*freq_res;
    delta_power_seq_eeg2 = [delta_power_seq_eeg2,delta_power];
    theta_power_seq_eeg2 = [theta_power_seq_eeg2,theta_power];
    alpha_power_seq_eeg2 = [alpha_power_seq_eeg2,alpha_power];
    lowB_power_seq_eeg2 = [lowB_power_seq_eeg2,lowB_power];
    beta_power_seq_eeg2 = [beta_power_seq_eeg2,beta_power];
    highB_power_seq_eeg2 = [highB_power_seq_eeg2,highB_power];
    gamma_power_seq_eeg2 = [gamma_power_seq_eeg2,gamma_power];
end
%calculate ralative power of each band
relative_delta_eeg2 = delta_power_seq_eeg2./(delta_power_seq_eeg2 + theta_power_seq_eeg2 + alpha_power_seq_eeg2 + beta_power_seq_eeg2 + gamma_power_seq_eeg2);
relative_theta_eeg2 = theta_power_seq_eeg2./(delta_power_seq_eeg2 + theta_power_seq_eeg2 + alpha_power_seq_eeg2 + beta_power_seq_eeg2 + gamma_power_seq_eeg2);
relative_alpha_eeg2 = alpha_power_seq_eeg2./(delta_power_seq_eeg2 + theta_power_seq_eeg2 + alpha_power_seq_eeg2 + beta_power_seq_eeg2 + gamma_power_seq_eeg2);
relative_beta_eeg2 = beta_power_seq_eeg2./(delta_power_seq_eeg2 + theta_power_seq_eeg2 + alpha_power_seq_eeg2 + beta_power_seq_eeg2 + gamma_power_seq_eeg2);
relative_gamma_eeg2 = gamma_power_seq_eeg2./(delta_power_seq_eeg2 + theta_power_seq_eeg2 + alpha_power_seq_eeg2 + beta_power_seq_eeg2 + gamma_power_seq_eeg2);
%remember to clear all the allocation for temporary resources
clear temp;clear temp_power;
clear delta_power;clear theta_power;clear alpha_power;
clear lowB_power;clear beta_power;clear highB_power;clear gamma_power

%% calculate the average absolute and relative power with time 
delta_power_seq = (delta_power_seq_eeg1 + delta_power_seq_eeg2)/2;
theta_power_seq = (theta_power_seq_eeg1+theta_power_seq_eeg2)/2; 
alpha_power_seq = (alpha_power_seq_eeg1+alpha_power_seq_eeg2)/2 ;
beta_power_seq = (beta_power_seq_eeg1+beta_power_seq_eeg2)/2; 
gamma_power_seq  = (gamma_power_seq_eeg1+gamma_power_seq_eeg2)/2;
lowB_power_seq = (lowB_power_seq_eeg1+lowB_power_seq_eeg2)/2;
highB_power_seq = (highB_power_seq_eeg1+highB_power_seq_eeg2)/2;

relative_delta = (relative_delta_eeg1+relative_delta_eeg2)/2;
relative_theta = (relative_theta_eeg1+relative_theta_eeg2)/2;
relative_alpha = (relative_alpha_eeg1+relative_alpha_eeg2)/2;
relative_beta = (relative_beta_eeg1+relative_beta_eeg2)/2;
relative_gamma = (relative_gamma_eeg1+relative_gamma_eeg2)/2;

%% calculate coherence of each interesting band
temp_eeg1 = [];temp_eeg2 = []; cxy_temp = [];f_temp = [];theta_temp = [];
alpha_temp = [];beta_temp = [];aloc_theta = [];aloc_alpha = [];aloc_beta = [];
gamma_temp = [];aloc_gamma = [];betagamma= [];
for i = 1:num_seg
    temp_eeg1 = eeg1(i*hop+1:i*hop+nfft);
    temp_eeg2 = eeg2(i*hop+1:i*hop+nfft);
    
    [cxy_temp,f_temp] = mscohere(temp_eeg1,temp_eeg2,hanning(250),150,250,fs);
    theta_temp = mean(cxy_temp(5:9));
    alpha_temp = mean(cxy_temp(9:14));
    beta_temp = mean(cxy_temp(14:31));
    gamma_temp = mean(cxy_temp(32:45));
    betagamma_temp = mean(cxy_temp(23:66));
    aloc_theta = [aloc_theta,theta_temp];
    aloc_alpha = [aloc_alpha,alpha_temp];
    aloc_beta = [aloc_beta,beta_temp];
    aloc_gamma = [aloc_gamma,gamma_temp];
    betagamma = [betagamma betagamma_temp];
end

%% difference pass for correlation coefficient parameter
eeg1_22to65 = bandpass(eeg1_notch,[22 65],fs);
eeg2_22to65 = bandpass(eeg2_notch,[22 65],fs);

corrcoef_seq = []; temp_corr = [];
for j = 1:num_seg
    temp_eeg1 = eeg1_22to65(j*hop:j*hop+nfft);
    temp_eeg2 = eeg2_22to65(j*hop:j*hop+nfft);
    temp_corr = corrcoef(temp_eeg1,temp_eeg2);
    corrcoef_seq = [corrcoef_seq, temp_corr(1,2)];
end

%% figure plot
figure;
plot(delta_power_seq,'k');hold on;plot(theta_power_seq);hold on;plot(alpha_power_seq,'r');...
    hold on;plot(lowB_power_seq,'g');hold on;plot(highB_power_seq,'y');hold on;plot(gamma_power_seq,'m')
legend('delta','theta','alpha','lowB','highB','gamma');
   xlabel('time/s','FontSize',24);ylim([0 50])
    ylabel('absolute power','FontSize',24);
     set(gca,'FontSize',24);
     
figure;
plot(relative_delta,'k');hold on;plot(relative_theta);hold on;plot(relative_alpha,'r');...
    hold on;plot(relative_beta,'g');hold on;plot(relative_gamma,'m');
legend('delta','theta','alpha','beta','gamma');ylim([0 1])
   xlabel('time/s','FontSize',24);
    ylabel('relative power','FontSize',24);
     set(gca,'FontSize',24)

figure;% using the lowBeta band to calculate tbr
tbr = theta_power_seq./lowB_power_seq;
B = filloutliers(tbr,'linear');
plot(B,'r')
 %plot(theta_power_seq./lowB_power_seq,'r');
 legend('theta/beta ratio');
  xlabel('time/s','FontSize',24);
    ylabel('ratio','FontSize',24);
     set(gca,'FontSize',24)
%title(regexprep(filename,'_','','emptymatch'));%delete the underscore in filename
     
figure;
plot(abs(corrcoef_seq));hold on;plot(aloc_theta,'r');hold on;plot(aloc_alpha,'k');hold on;plot(aloc_beta,'g');...
    hold on;plot(aloc_gamma,'m');  plot(betagamma,'y'); 
 legend('cc','theta','alpha','beta','gamma','betagamma');
  xlabel('time/s','FontSize',24);
    ylabel('cc','FontSize',24);
     set(gca,'FontSize',24);title('����Ժ������');
     
figure;
%alpha_asy = log10() - log10(relative_alpha_eeg1);ylim([-1 1]);
alpha_asy = alpha_power_seq_eeg2 - alpha_power_seq_eeg1;
bar(alpha_asy);ylim([-1 1])
  xlabel('time/s','FontSize',24);
    ylabel('alpha asymmetry','FontSize',24);
     set(gca,'FontSize',24);
     legend('right-left');
     
figure;
plot(highB_power_seq./beta_power_seq);ylim([0.2 0.8]);
  xlabel('time/s','FontSize',24);
    ylabel('ratio','FontSize',24);
     set(gca,'FontSize',24);
     legend('HighB/beta');
 
figure;
bar(beta_power_seq_eeg2 - beta_power_seq_eeg1);ylim([-1 1]);
 xlabel('time/s','FontSize',24);
    ylabel('amplitude','FontSize',24);
     set(gca,'FontSize',24);
      legend('right hemisphere - left hemisphere');
     title('brain activity beta');
     
figure;
bar(gamma_power_seq_eeg2 - gamma_power_seq_eeg1);ylim([-1 1]);
 xlabel('time/s','FontSize',24);
    ylabel('amplitude','FontSize',24);
     set(gca,'FontSize',24);
      legend('right hemisphere - left hemisphere');
     title('brain activity gamma');

     
% figure;
% diff_highB = highB_power_seq_eeg2 - highB_power_seq_eeg1;
% % diff_beta = beta_power_seq_eeg2 - highB_power_seq_eeg1
% plot(diff_highB./beta_power_seq);%ylim([-1 , 1]);
%   xlabel('time/s','FontSize',24);
%     ylabel('ratio','FontSize',24);
%      set(gca,'FontSize',24);
%      legend('HighB/beta');

figure;
bar(highB_power_seq_eeg2 - highB_power_seq_eeg1);ylim([-1 1]);
 xlabel('time/s','FontSize',24);
    ylabel('amplitude','FontSize',24);
     set(gca,'FontSize',24);
      legend('right hemisphere - left hemisphere');
     title('brain high beta');
     
     



function [absolute_power, relative_power] = Calculate_abs_rela_power(eeg1_filtered, fs)
% ����5��Ƶ�������������delta\theta\alpha\beta\gamma��

%% calculate the absolute power of AF7
sig = eeg1_filtered; % signal to be analysed
data_len = length(sig);
nfft = fs*5; % calculate the power every 5 second
hop = fs; % sliding window of 1 second with previous segment
%          delta,theta,alpha,low_beta,beta, high beta,gamma 
freq_band = [1 4; 4 8; 8 13; 13 37; 37 45];
f = fs * ((0:nfft/2))/nfft; %frequency resolution, depending on nfft
relative_index = freq_band*nfft/fs+1;%index of each frequency bin
freq_res = fs/nfft ;            % Ƶ�ʷֱ��� frequency resolution
%allocate space saving all the outputs
temp = []; % current segment, from i*hop to i*hop+nfft
temp_power = [];% absolute power of all frequency
delta_power_seq_eeg1 = [];theta_power_seq_eeg1 = [];
alpha_power_seq_eeg1 = [];lowB_power_seq_eeg1 = [];beta_power_seq_eeg1 = [];
highB_power_seq_eeg1 = [];gamma_power_seq_eeg1 = [];

delta_power = [];theta_power = []; alpha_power = [];
lowB_power = [];beta_power = [];highB_power = [];gamma_power = [];

num_seg = floor((data_len-nfft)/hop) - 1; % how many times you will calculate the fft
for i = 1:num_seg
    temp = sig(i*hop+1:i*hop+nfft);
%     temp_power = 2 * abs(fft(temp))/nfft;% calcuate ampltiude distribution of raw data 
    mag = abs(fft(temp,nfft));
    temp_power= 2 * mag.^2/(nfft*fs); %calculate psd of real time signal
    P1 = temp_power(1:nfft/2 + 1);
    delta_power = sum(P1(relative_index(1,1):relative_index(1,2)))*freq_res; 
    theta_power = sum(P1(relative_index(2,1):relative_index(2,2)))*freq_res;
    alpha_power = sum(P1(relative_index(3,1):relative_index(3,2)))*freq_res;
    beta_power = sum(P1(relative_index(4,1):relative_index(4,2)))*freq_res;
    gamma_power = sum(P1(relative_index(5,1):relative_index(5,2)))*freq_res;
    delta_power_seq_eeg1 = [delta_power_seq_eeg1,delta_power];
    theta_power_seq_eeg1 = [theta_power_seq_eeg1,theta_power];
    alpha_power_seq_eeg1 = [alpha_power_seq_eeg1,alpha_power];
    beta_power_seq_eeg1 = [beta_power_seq_eeg1,beta_power];
    gamma_power_seq_eeg1 = [gamma_power_seq_eeg1,gamma_power];
end
absolute_power = [delta_power_seq_eeg1;theta_power_seq_eeg1;alpha_power_seq_eeg1;beta_power_seq_eeg1;gamma_power_seq_eeg1];


%calculate relative power of each band
relative_delta_eeg1 = delta_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
relative_theta_eeg1 = theta_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
relative_alpha_eeg1 = alpha_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
relative_beta_eeg1 = beta_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);
relative_gamma_eeg1 = gamma_power_seq_eeg1./(delta_power_seq_eeg1 + theta_power_seq_eeg1 + alpha_power_seq_eeg1 + beta_power_seq_eeg1 + gamma_power_seq_eeg1);

relative_power = [relative_delta_eeg1;relative_theta_eeg1;relative_alpha_eeg1;relative_beta_eeg1;relative_gamma_eeg1];

end



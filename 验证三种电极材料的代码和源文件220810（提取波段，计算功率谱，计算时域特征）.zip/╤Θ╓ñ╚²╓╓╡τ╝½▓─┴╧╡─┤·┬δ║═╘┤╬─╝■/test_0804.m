clc;close all;clear;
tic;
% ����Ƶ��ͼ
%% pick the input will be analyzed
filename = 'demo_2021_12_01_05_37.csv';

T = readtable(filename,'HeaderLines',4); % for non_numeric array
eeg1 = T{:,2};
eeg2 = T{:,3};

% delete Nan values if any
eeg1(isnan(eeg1)) = [];
eeg2(isnan(eeg2)) = [];
% two channels dimension equivalence check
if ~isequal(length(eeg1),length(eeg2))
    eeg1 = eeg1(1:min(length(eeg1),length(eeg2)));
    eeg2 = eeg2(1:min(length(eeg1),length(eeg2)));
end
%% filtering the raw data for further process
fs = 250; % sampling frequency
T = 1/fs;  
data_len = length(eeg1); % length of selected signal
time_vector = (0:data_len-1)/fs; % time vector
data_dur = data_len/fs; % recording duration, in seconds



